<template>
  <input type="text" placeholder="입력해주세요!" />
</template>

<script>
export default {
  name: "InputComponent",
};
</script>

<style scoped>
</style>