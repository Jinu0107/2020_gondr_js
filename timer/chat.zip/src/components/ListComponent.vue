<template>
<div>
    <h1>여기는 유저리스트가 보이는 곳입니다.</h1>
</div>
</template>

<script>
export default {
    name : 'ListComponent'
}
</script>

<style scoped>

</style>