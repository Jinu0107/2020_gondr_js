<template>
  <button>보내기</button>
</template>

<script>
export default {
  name: "ButtonComponent",
};
</script>

<style scoped>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
button {
  border: none;
  background-color: skyblue;
  color: #fff;
}
</style>